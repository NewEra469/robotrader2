'use strict';
/* RoboTrader server: MetaTrader 5 (via the local bridge) market data + orders over REST and WebSocket,
   controlled from the web dashboard in ./public. Zero npm dependencies, Node 18+.
   No dashboard API key: access control is left to your hosting platform (see README). */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { create: createBroker } = require('./src/brokers');
const { Store } = require('./src/store');
const { Bot } = require('./src/bot');
const Strategy = require('./src/strategy');
const { attach: attachWs } = require('./src/ws');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };
const PUBLIC = path.join(__dirname, 'public');

/** Secret used only to encrypt saved broker credentials. Generated once and stored in DATA_DIR (mode 0600). */
function loadOrCreateSecret(dir) {
  const file = path.join(dir, '.creds-secret');
  try { const s = fs.readFileSync(file, 'utf8').trim(); if (s.length >= 32) return s; } catch { /* first start */ }
  const s = crypto.randomBytes(32).toString('hex');
  try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file, s, { mode: 0o600 }); }
  catch { console.warn('  Could not write the credentials secret to DATA_DIR; saved broker logins will not survive a restart.'); }
  return s;
}

function createApp(opts = {}) {
  const env = opts.env || process.env;
  const dataDir = env.DATA_DIR || path.join(__dirname, 'data');
  const store = opts.store || new Store(dataDir, loadOrCreateSecret(dataDir));
  const ctx = { broker: null, brokerName: null, creds: null };
  const bot = new Bot({ getBroker: () => ctx.broker, store, now: opts.now, tickMs: +env.TICK_MS || 5000, requireLiveConfirm: env.REQUIRE_LIVE_CONFIRM !== 'false' });
  bot.onChange = () => { snap.at = 0; snap.data = null; };
  const corsList = (env.CORS_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
  // CORS_ORIGIN accepts exact origins and wildcards such as https://*.example.app (only needed for other sites calling the API)
  const originAllowed = o => corsList.some(rule => rule === o || (rule.includes('*.') && (() => { try { const [scheme, host] = rule.split('//'); const u = new URL(o); return o.startsWith(scheme + '//') && u.host.endsWith(host.replace('*', '')) && u.host.length > host.length - 1; } catch { return false; } })()));
  let app_ws = null;
  const failures = new Map();             // TradingView passphrase guesses per IP
  const startedAt = Date.now();
  const snap = { at: 0, key: '', data: null, p: null };

  /* ---------- helpers ---------- */
  const send = (res, code, obj, headers = {}) => { const b = JSON.stringify(obj); res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers }); res.end(b); };
  const fail = (res, e, headers) => { const code = e.status && e.status >= 400 && e.status < 600 ? e.status : 502; send(res, code, { success: false, message: e.message, code: e.code }, headers); };
  const readBody = req => new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > 64 * 1024) { reject(Object.assign(new Error('Body too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(Object.assign(new Error('Invalid JSON'), { status: 400 })); } });
    req.on('error', reject);
  });
  const ip = req => (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
  const requireConn = () => { if (!ctx.broker) throw Object.assign(new Error('Not connected to a broker — enter your MT5 details and press Connect'), { status: 400 }); return ctx.broker; };
  const safeBroker = () => ctx.broker ? { name: ctx.brokerName, label: ctx.broker.label, isReal: ctx.broker.isReal } : null;

  async function connect(body, { persist = true } = {}) {
    if (bot.running) throw Object.assign(new Error('Stop the bot before changing the broker connection'), { status: 409 });
    const name = String(body.broker || 'mt5').toLowerCase();
    const b = createBroker(name);
    const acct = await b.connect(body);
    ctx.broker = b; ctx.brokerName = name; snap.at = 0; setImmediate(() => app_ws && app_ws.restream());
    const creds = {}; for (const [k, v] of Object.entries(body)) if (v !== undefined && v !== '') creds[k] = v;
    ctx.creds = creds;
    if (persist && body.save !== false) store.saveCreds({ broker: name, ...creds });
    bot.addLog('info', `Connected to ${b.label}${b.isReal === false ? ' (demo account)' : ' (REAL account)'}`);
    return acct;
  }

  function envCreds() {
    const name = (env.BROKER || '').toLowerCase();
    if (env.MT5_LOGIN && env.MT5_PASSWORD && env.MT5_SERVER && (!name || name === 'mt5')) return { broker: 'mt5', login: env.MT5_LOGIN, password: env.MT5_PASSWORD, server: env.MT5_SERVER };
    if (name === 'oanda' && env.OANDA_TOKEN) return { broker: 'oanda', token: env.OANDA_TOKEN, accountId: env.OANDA_ACCOUNT_ID, env: env.OANDA_ENV || 'practice' };
    return null;
  }

  /* On start-up: connect with env credentials or the saved (encrypted) login, then resume a running bot. */
  async function boot() {
    const c = envCreds() || store.loadCreds();
    if (!c) return;
    try { await connect(c, { persist: false }); } catch (e) { bot.addLog('error', `Auto-connect failed: ${e.message}`); return; }
    const saved = bot.saved;
    let cfg = null, resume = false;
    if (saved?.running && saved.cfg) { cfg = saved.cfg; resume = true; }
    else if (env.AUTOSTART === 'true' && env.AUTOSTART_CONFIG) { try { cfg = JSON.parse(env.AUTOSTART_CONFIG); } catch { bot.addLog('error', 'AUTOSTART_CONFIG is not valid JSON'); } }
    if (cfg) { try { await bot.start(cfg, { resume, confirmLive: true }); } catch (e) { bot.addLog('error', `Auto-resume failed: ${e.message}`); } }
  }

  /* One aggregated, cached read for the dashboard (protects broker rate limits). */
  async function snapshot(symbol) {
    const key = symbol || '';
    if (snap.p && snap.key === key) return snap.p;
    if (snap.data && snap.key === key && Date.now() - snap.at < 1500) return snap.data;
    snap.key = key;
    snap.p = (async () => {
      const b = ctx.broker, errors = {}, out = { account: null, positions: [], price: null };
      await Promise.all([
        b.getAccount().then(a => { out.account = a; }).catch(e => { errors.account = e.message; }),
        b.getPositions().then(p => { out.positions = p; }).catch(e => { errors.positions = e.message; }),
        symbol ? b.getPrice(symbol).then(p => { out.price = p; }).catch(e => { errors.price = e.message; }) : null,
      ]);
      out.errors = errors; snap.data = out; snap.at = Date.now(); snap.p = null; return out;
    })();
    return snap.p;
  }

  /* ---------- routes ---------- */
  const routes = {
    'GET /api/health': async (req, res) => send(res, 200, { ok: true, uptime: Math.round((Date.now() - startedAt) / 1000), connected: !!ctx.broker, running: bot.running }),

    'POST /api/connect': async (req, res, q, body) => {
      const acct = await connect(body);
      const { raw, ...a } = acct;
      send(res, 200, { success: true, broker: safeBroker(), account: a, persisted: store.ok && body.save !== false });
    },
    'POST /api/disconnect': async (req, res) => {
      if (bot.running) throw Object.assign(new Error('Stop the bot first'), { status: 409 });
      ctx.broker = null; ctx.brokerName = null; ctx.creds = null; store.clearCreds(); app_ws.restream(); bot.addLog('info', 'Broker disconnected and saved credentials erased');
      send(res, 200, { success: true });
    },

    'GET /api/state': async (req, res, q) => {
      const base = { success: true, serverTime: Date.now(), connected: !!ctx.broker, broker: safeBroker(), bot: bot.status(), log: bot.log.slice(0, 80), journal: bot.journal.slice(0, 80), persistent: store.ok, envConfigured: !!envCreds() };
      if (!ctx.broker) return send(res, 200, base);
      const symbol = q.get('symbol') || bot.cfg?.symbol || null;
      const s = await snapshot(symbol);
      let account = null;
      if (s.account) {
        const d = bot.trackDay(s.account), { raw, ...a } = s.account, today = a.equity - d.equity;
        account = { ...a, floating: a.equity - a.balance, today, pct: d.equity ? (today / d.equity) * 100 : 0 };
      }
      send(res, 200, { ...base, account, positions: s.positions, price: s.price, errors: s.errors });
    },

    // Latest ticks from the WebSocket stream cache; falls back to a REST price call.
    'GET /api/ticks': async (req, res, q) => {
      const b = requireConn(), syms = String(q.get('symbols') || '').split(',').map(x => x.trim().toUpperCase()).filter(Boolean).slice(0, 30);
      if (!syms.length) throw Object.assign(new Error('symbols is required, e.g. ?symbols=EURUSD,XAUUSD'), { status: 400 });
      const out = {};
      await Promise.all(syms.map(async s => { const t = app_ws.last.get(s); if (t && Date.now() / 1000 - t.time < 30) out[s] = { ...t, source: 'stream' }; else try { out[s] = { symbol: s, ...(await b.getPrice(s)), source: 'rest' }; } catch (e) { out[s] = { symbol: s, error: e.message }; } }));
      send(res, 200, { success: true, ticks: out });
    },
    'GET /api/stream': async (req, res) => send(res, 200, { success: true, ...app_ws.status() }),

    // TradingView alert → webhook (paid TradingView plan). Disabled unless TV_WEBHOOK_SECRET is set.
    // Body JSON: {passphrase, action:'buy'|'sell'|'close', symbol, lots?, sl?, tp?}
    'POST /api/webhook/tradingview': async (req, res, q, body) => {
      const secret = env.TV_WEBHOOK_SECRET;
      if (!secret) throw Object.assign(new Error('TradingView webhook is disabled (set TV_WEBHOOK_SECRET)'), { status: 404 });
      if ((failures.get(ip(req)) || { n: 0 }).n >= 20) throw Object.assign(new Error('Too many wrong attempts — wait 10 minutes'), { status: 429 });
      const ok = String(body.passphrase || '').length === secret.length && crypto.timingSafeEqual(Buffer.from(String(body.passphrase)), Buffer.from(secret));
      if (!ok) { const f = failures.get(ip(req)) || { n: 0, t: Date.now() }; f.n++; failures.set(ip(req), f); throw Object.assign(new Error('Wrong passphrase'), { status: 401 }); }
      const b = requireConn(), action = String(body.action || '').toLowerCase(), symbol = String(body.symbol || '').toUpperCase().replace(/^[A-Z]+:/, '');
      if (!symbol) throw Object.assign(new Error('symbol is required'), { status: 400 });
      if (b.isReal !== false && env.TV_ALLOW_LIVE !== 'true') throw Object.assign(new Error('Real-money account: set TV_ALLOW_LIVE=true to let webhooks trade it'), { status: 409 });
      const mine = (await b.getPositions()).filter(p => p.mine && p.symbol.toUpperCase() === symbol);
      if (action === 'close') { for (const p of mine) await bot.closeById(p.id); snap.at = 0; return send(res, 200, { success: true, closed: mine.length }); }
      if (!['buy', 'sell'].includes(action)) throw Object.assign(new Error('action must be buy, sell or close'), { status: 400 });
      const type = action.toUpperCase();
      if (mine.some(p => p.type === type)) return send(res, 200, { success: true, skipped: `already ${type}` });
      for (const p of mine) await bot.closeById(p.id);
      const r = await bot.manualOrder({ symbol, type, lots: +body.lots || +env.TV_LOTS || 0.01, sl: +body.sl || 0, tp: +body.tp || 0 });
      snap.at = 0; bot.addLog('signal', `TradingView alert: ${type} ${symbol}`);
      send(res, 200, { success: true, order: r });
    },

    'GET /api/candles': async (req, res, q) => {
      const b = requireConn(), symbol = q.get('symbol'), tf = +q.get('tf') || 60;
      if (!symbol) throw Object.assign(new Error('symbol is required'), { status: 400 });
      const [inst, candles] = await Promise.all([b.getInstrument(symbol), b.getCandles(symbol, tf, Math.min(+q.get('count') || 300, 600))]);
      send(res, 200, { success: true, symbol, tf, digits: inst.digits, pip: inst.pip, minLot: inst.minLot, candles: candles.map(c => ({ t: c.t, o: c.o, h: c.h, l: c.l, c: c.c, complete: c.complete })) });
    },

    // Indicators computed on the broker's closed candles: /api/indicators?symbol=XAUUSD&tf=60&list=ema:50,rsi:14&bars=3
    'GET /api/indicators': async (req, res, q) => {
      const b = requireConn(), symbol = q.get('symbol'), tf = +q.get('tf') || 60, bars = Math.min(Math.max(+q.get('bars') || 1, 1), 200);
      if (!symbol) throw Object.assign(new Error('symbol is required'), { status: 400 });
      const candles = await b.getCandles(symbol, tf, 500), closed = candles.filter(c => c.complete);
      const ser = Strategy.indicators(closed, q.get('list') || 'ema:50,rsi:14,atr:14');
      const take = a => a.slice(-bars).map(x => (Number.isFinite(x) ? +x.toFixed(6) : null));
      const values = {}; for (const [k, v] of Object.entries(ser)) values[k] = bars === 1 ? take(v)[0] : take(v);
      send(res, 200, { success: true, symbol, tf, closedCandles: closed.length, lastClosedTime: closed.length ? closed[closed.length - 1].t : null, values, forming: candles.length && !candles[candles.length - 1].complete ? { t: candles[candles.length - 1].t, close: candles[candles.length - 1].c } : null });
    },

    'GET /api/symbols': async (req, res, q) => { const b = requireConn(); send(res, 200, { success: true, symbols: await b.searchSymbols(q.get('q')) }); },

    'POST /api/bot/start': async (req, res, q, body) => {
      requireConn();
      await bot.start(body.config || body, { confirmLive: body.confirmLive === true });
      send(res, 200, { success: true, bot: bot.status() });
    },
    'POST /api/bot/stop': async (req, res, q, body) => { await bot.stop({ closePositions: body.closePositions === true }); send(res, 200, { success: true, bot: bot.status() }); },

    'POST /api/order': async (req, res, q, body) => {
      requireConn();
      if (!bot.running && ctx.broker.isReal !== false && body.confirmLive !== true) throw Object.assign(new Error('Real-money account: confirm the order'), { status: 409, code: 'CONFIRM_LIVE' });
      const r = await bot.manualOrder({ symbol: String(body.symbol || ''), type: body.type, lots: +body.lots, sl: +body.sl || 0, tp: +body.tp || 0 });
      snap.at = 0; send(res, 200, { success: true, order: r });
    },
    'POST /api/positions/close': async (req, res, q, body) => { requireConn(); const r = await bot.closeById(body.id); snap.at = 0; send(res, 200, { success: true, result: r }); },
    'POST /api/positions/close-all': async (req, res) => { requireConn(); const r = await bot.closeAll('Close all'); snap.at = 0; send(res, 200, { success: true, ...r }); },

    'GET /api/diagnostics': async (req, res, q) => {
      const steps = [], add = (name, ok, detail) => steps.push({ name, ok, detail: String(detail ?? '') });
      add('Server reachable', true, 'API responded');
      const b = ctx.broker;
      if (!b) { add('Broker connected', false, 'Not connected. Enter your MT5 login, password and server, then press Connect.'); return send(res, 200, { success: false, steps }); }
      add('Broker connected', true, `${b.label} — ${b.isReal === false ? 'DEMO account' : 'REAL-MONEY account'}`);
      const symbol = q.get('symbol') || bot.cfg?.symbol || 'EURUSD', tf = +q.get('tf') || 60;
      const step = async (name, fn) => { try { add(name, true, await fn()); return true; } catch (e) { add(name, false, e.message); return false; } };
      await step('Account information', async () => { const a = await b.getAccount(); return `balance ${a.balance} ${a.currency || ''}, equity ${a.equity}`; });
      const okI = await step(`Symbol ${symbol}`, async () => { const i = await b.getInstrument(symbol); return `${i.brokerSymbol} · digits ${i.digits} · 1 pip = ${i.pip} · min lot ${i.minLot}`; });
      if (okI) {
        await step('Live price', async () => { const p = await b.getPrice(symbol); return `bid ${p.bid} / ask ${p.ask}${p.tradeable === false ? ' (market closed)' : ''}`; });
        await step('Candle history', async () => { const c = await b.getCandles(symbol, tf, 300); if (!c.length) throw new Error('No candles returned'); const l = c[c.length - 1]; return `${c.length} candles, newest ${new Date(l.t * 1000).toISOString()}`; });
      }
      await step('Open positions', async () => `${(await b.getPositions()).length} open`);
      add('Bot', true, bot.running ? 'running' : 'stopped');
      send(res, 200, { success: steps.every(s => s.ok), steps });
    },
  };

  /* ---------- http server ---------- */
  function sendFile(res, file) {
    fs.readFile(file, (err, buf) => {
      if (err) { res.writeHead(404, { 'content-type': 'text/plain' }); return res.end('Not found'); }
      res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' });
      res.end(buf);
    });
  }
  function serveStatic(res, pathname) {
    if (pathname === '/strategy.js') return sendFile(res, path.join(__dirname, 'src', 'strategy.js'));
    const rel = pathname === '/' ? '/index.html' : pathname;
    const file = path.normalize(path.join(PUBLIC, rel));
    if (file !== PUBLIC && !file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }
    sendFile(res, file);
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://x'), origin = req.headers.origin;
    const cors = origin && originAllowed(origin) ? { 'access-control-allow-origin': origin, 'access-control-allow-headers': 'content-type', 'access-control-allow-methods': 'GET,POST,OPTIONS', vary: 'Origin' } : {};
    if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
    if (url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
    if (!url.pathname.startsWith('/api/')) return serveStatic(res, url.pathname);
    const handler = routes[`${req.method} ${url.pathname}`];
    if (!handler) return send(res, 404, { success: false, message: 'Unknown endpoint' }, cors);
    try {
      const body = req.method === 'POST' ? await readBody(req) : {};
      res.setHeader('x-content-type-options', 'nosniff');
      for (const [k, v] of Object.entries(cors)) res.setHeader(k, v);
      await handler(req, res, url.searchParams, body);
    } catch (e) { if (!res.headersSent) fail(res, e, cors); }
  });

  /* ---------- WebSocket: live ticks + bot events on /ws ---------- */
  const ws = app_ws = attachWs(server, { getBroker: () => ctx.broker });
  const prevLog = bot.addLog.bind(bot);
  bot.addLog = (k, m) => { prevLog(k, m); ws.event(k, m); };

  return { server, bot, ctx, boot, store, connect, ws };
}

module.exports = { createApp };

if (require.main === module) {
  const app = createApp();
  const port = +process.env.PORT || 3000;
  const host = process.env.HOST || '0.0.0.0';
  app.server.listen(port, host, () => {
    console.log(`\n  RoboTrader dashboard running on port ${port}\n`);
    app.boot().catch(e => console.error('boot error', e.message));
  });
  const bye = () => { app.bot.persist(); app.store.flush(); process.exit(0); };
  process.on('SIGTERM', bye); process.on('SIGINT', bye);
  process.on('unhandledRejection', e => console.error('unhandledRejection', e && e.message));
}
