/* Shared by the server (bot) and the browser (chart). UMD, no dependencies. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Strategy = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  

  function sma(v, p) { const o = new Array(v.length).fill(NaN); let s = 0; for (let i = 0; i < v.length; i++) { s += v[i]; if (i >= p) s -= v[i - p]; if (i >= p - 1) o[i] = s / p; } return o; }
  function ema(v, p) {
    const o = new Array(v.length).fill(NaN); if (v.length < p) return o;
    const k = 2 / (p + 1); let e = 0; for (let i = 0; i < p; i++) e += v[i]; e /= p; o[p - 1] = e;
    for (let i = p; i < v.length; i++) { e = v[i] * k + e * (1 - k); o[i] = e; } return o;
  }
  function wma(v, p) { const o = new Array(v.length).fill(NaN), den = p * (p + 1) / 2; for (let i = p - 1; i < v.length; i++) { let s = 0; for (let j = 0; j < p; j++) s += v[i - p + 1 + j] * (j + 1); o[i] = s / den; } return o; }
  function rsi(v, p) {   // Wilder
    const o = new Array(v.length).fill(NaN); if (v.length <= p) return o;
    let g = 0, l = 0; for (let i = 1; i <= p; i++) { const d = v[i] - v[i - 1]; if (d >= 0) g += d; else l -= d; }
    g /= p; l /= p; o[p] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
    for (let i = p + 1; i < v.length; i++) { const d = v[i] - v[i - 1]; g = (g * (p - 1) + Math.max(d, 0)) / p; l = (l * (p - 1) + Math.max(-d, 0)) / p; o[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l); }
    return o;
  }
  function atr(h, lo, c, p) {   // Wilder
    const o = new Array(c.length).fill(NaN); if (c.length <= p) return o;
    const tr = c.map((_, i) => i === 0 ? h[0] - lo[0] : Math.max(h[i] - lo[i], Math.abs(h[i] - c[i - 1]), Math.abs(lo[i] - c[i - 1])));
    let a = 0; for (let i = 1; i <= p; i++) a += tr[i]; a /= p; o[p] = a;
    for (let i = p + 1; i < c.length; i++) { a = (a * (p - 1) + tr[i]) / p; o[i] = a; } return o;
  }
  function bbands(v, p, k) {
    const mid = sma(v, p), up = [], lo = [];
    for (let i = 0; i < v.length; i++) { if (isNaN(mid[i])) { up.push(NaN); lo.push(NaN); continue; } let s2 = 0; for (let j = i - p + 1; j <= i; j++) s2 += (v[j] - mid[i]) ** 2; const sd = Math.sqrt(s2 / p); up.push(mid[i] + k * sd); lo.push(mid[i] - k * sd); }
    return { mid, up, lo };
  }
  function stoch(h, lo, c, p, d) {
    const k = c.map((_, i) => { if (i < p - 1) return NaN; let hh = -Infinity, ll = Infinity; for (let j = i - p + 1; j <= i; j++) { hh = Math.max(hh, h[j]); ll = Math.min(ll, lo[j]); } return hh === ll ? 50 : (c[i] - ll) / (hh - ll) * 100; });
    const first = k.findIndex(x => !isNaN(x)); return { k, d: first < 0 ? k.slice() : new Array(first).fill(NaN).concat(sma(k.slice(first), d)) };
  }
  /** spec like "ema:50,sma:200,rsi:14,atr:14,bb:20:2,macd:12:26:9,stoch:14:3,wma:21" on candles [{o,h,l,c}] → {name: series} */
  function indicators(candles, spec) {
    const c = candles.map(x => x.c), h = candles.map(x => x.h), lo = candles.map(x => x.l), out = {};
    for (const item of String(spec).split(',').map(x => x.trim()).filter(Boolean)) {
      const [n, ...a] = item.toLowerCase().split(':'), A = a.map(Number);
      if (A.some(x => !(x > 0))) throw Object.assign(new Error(`Bad indicator parameters: ${item}`), { status: 400 });
      if (n === 'ema' || n === 'sma' || n === 'wma') out[`${n}(${A[0]})`] = MA(n.toUpperCase(), c, A[0]);
      else if (n === 'rsi') out[`rsi(${A[0] || 14})`] = rsi(c, A[0] || 14);
      else if (n === 'atr') out[`atr(${A[0] || 14})`] = atr(h, lo, c, A[0] || 14);
      else if (n === 'bb') { const b = bbands(c, A[0] || 20, A[1] || 2); out[`bb_upper(${A[0] || 20},${A[1] || 2})`] = b.up; out[`bb_mid(${A[0] || 20})`] = b.mid; out[`bb_lower(${A[0] || 20},${A[1] || 2})`] = b.lo; }
      else if (n === 'macd') { const m = macd(c, A[0] || 12, A[1] || 26, A[2] || 9); const t = `${A[0] || 12},${A[1] || 26},${A[2] || 9}`; out[`macd(${t})`] = m.line; out[`macd_signal(${t})`] = m.sig; out[`macd_hist(${t})`] = m.hist; }
      else if (n === 'stoch') { const st = stoch(h, lo, c, A[0] || 14, A[1] || 3); out[`stoch_k(${A[0] || 14})`] = st.k; out[`stoch_d(${A[1] || 3})`] = st.d; }
      else throw Object.assign(new Error(`Unknown indicator "${n}". Supported: ema, sma, wma, rsi, atr, bb, macd, stoch`), { status: 400 });
    }
    return out;
  }
  const MA = (t, v, p) => t === 'SMA' ? sma(v, p) : t === 'WMA' ? wma(v, p) : ema(v, p);

  function macd(v, f, s, sg) {
    const ef = ema(v, f), es = ema(v, s);
    const line = v.map((_, i) => isNaN(ef[i]) || isNaN(es[i]) ? NaN : ef[i] - es[i]);
    const first = line.findIndex(x => !isNaN(x));
    if (first < 0) return { line, sig: line.slice(), hist: line.slice() };
    const sigp = ema(line.slice(first), sg), sig = new Array(first).fill(NaN).concat(sigp);
    return { line, sig, hist: line.map((x, i) => isNaN(x) || isNaN(sig[i]) ? NaN : x - sig[i]) };
  }

  /* cfg: {strat:'pma'|'cross'|'macd', maType, maPeriod, fastType, fastPeriod, slowType, slowPeriod, macdFast, macdSlow, macdSignal} */
  function compute(closes, c) {
    if (c.strat === 'macd') {
      const m = macd(closes, c.macdFast, c.macdSlow, c.macdSignal);
      return { overlays: [], macd: m, diff: m.line.map((x, i) => x - m.sig[i]), title: `MACD(${c.macdFast},${c.macdSlow},${c.macdSignal})` };
    }
    if (c.strat === 'cross') {
      const a = MA(c.fastType, closes, c.fastPeriod), b = MA(c.slowType, closes, c.slowPeriod);
      return { overlays: [{ name: `${c.fastType}(${c.fastPeriod})`, color: '#22d3ee', vals: a }, { name: `${c.slowType}(${c.slowPeriod})`, color: '#fbbf24', vals: b }], macd: null, diff: a.map((x, i) => x - b[i]) };
    }
    const m = MA(c.maType, closes, c.maPeriod);
    return { overlays: [{ name: `${c.maType}(${c.maPeriod})`, color: '#fbbf24', vals: m }], macd: null, diff: closes.map((x, i) => x - m[i]) };
  }

  /* +1 = bullish side (price above MA / fast above slow / MACD above signal), -1 bearish, 0 unknown */
  function states(closes, c) {
    const ind = compute(closes, c);
    return { ind, state: ind.diff.map(d => (isNaN(d) ? 0 : Math.sign(d))) };
  }

  const TYPES = ['EMA', 'SMA', 'WMA'];
  function validate(c) {
    if (!c || typeof c !== 'object') return 'Missing config';
    if (!c.symbol || !/^[A-Za-z0-9_.#\-]{2,24}$/.test(c.symbol)) return 'Invalid symbol';
    if (![1, 5, 15, 30, 60, 240, 1440].includes(c.tfMin)) return 'Timeframe must be 1, 5, 15, 30, 60, 240 or 1440 minutes';
    if (!(c.lots >= 0.01 && c.lots <= 100)) return 'Lot size must be between 0.01 and 100';
    for (const k of ['sl', 'tp', 'maxLoss']) if (!(c[k] >= 0)) return `${k} must be 0 or more`;
    const int = (x, lo, hi) => Number.isInteger(x) && x >= lo && x <= hi;
    if (c.strat === 'pma') { if (!TYPES.includes(c.maType) || !int(c.maPeriod, 2, 500)) return 'MA period must be 2–500'; }
    else if (c.strat === 'cross') {
      if (!TYPES.includes(c.fastType) || !TYPES.includes(c.slowType)) return 'Invalid MA type';
      if (!int(c.fastPeriod, 2, 500) || !int(c.slowPeriod, 3, 500) || c.slowPeriod <= c.fastPeriod) return 'Slow MA period must be larger than fast';
    } else if (c.strat === 'macd') {
      if (!int(c.macdFast, 2, 200) || !int(c.macdSlow, 3, 400) || !int(c.macdSignal, 2, 100) || c.macdSlow <= c.macdFast) return 'MACD slow must be larger than fast';
    } else return 'Unknown strategy';
    return null;
  }

  return { sma, ema, wma, MA, macd, rsi, atr, bbands, stoch, indicators, compute, states, validate };
});
