const crypto = require('crypto');

class ApiError extends Error {
  constructor(message, status, data) { super(message); this.status = status; this.data = data; }
}

/** Small fetch wrapper with timeout. Never puts secrets in error messages. */
async function http(method, url, { headers = {}, body, timeout = 15000 } = {}) {
  const ctl = new AbortController();
  const to = setTimeout(() => ctl.abort(), timeout);
  const u = new URL(url);
  const where = `${method} ${u.host}${u.pathname}`;
  try {
    const res = await fetch(url, {
      method,
      headers: { 'content-type': 'application/json', accept: 'application/json', ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctl.signal,
    });
    const text = await res.text();
    let data = null;
    if (text) { try { data = JSON.parse(text); } catch { data = text; } }
    if (!res.ok) {
      const detail = data && typeof data === 'object'
        ? (data.message || data.errorMessage || data.error || data.stringCode || JSON.stringify(data).slice(0, 300))
        : String(data || '').slice(0, 300);
      throw new ApiError(`${where} → HTTP ${res.status}${detail ? ': ' + detail : ''}`, res.status, data);
    }
    return { status: res.status, data, headers: res.headers };
  } catch (e) {
    if (e instanceof ApiError) throw e;
    if (e.name === 'AbortError') throw new ApiError(`${where} timed out after ${timeout / 1000}s`, 504);
    throw new ApiError(`${where} failed: ${e.cause?.code || e.message}`, 0);
  } finally { clearTimeout(to); }
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
const rid = (n = 32) => crypto.randomBytes(n).toString('hex').slice(0, n);
const num = x => (x === null || x === undefined || x === '' ? NaN : +x);
const round = (x, d) => +(+x).toFixed(d);

module.exports = { http, ApiError, sleep, rid, num, round };
