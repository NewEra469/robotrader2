/* Minimal RFC 6455 WebSocket server (zero dependencies) + live price hub.
   No dashboard key: connect to ws(s)://<host>/ws and the socket is ready immediately.
   Protocol (JSON text frames):
     client → {op:'subscribe', symbols:['EURUSD','XAUUSD']}   / {op:'unsubscribe', symbols:[...]}
     client → {op:'ping'}
     server → {type:'ready'} | {type:'tick', symbol,bid,ask,time,tradeable} | {type:'event', kind,msg,t} | {type:'stream', status} | {type:'error', message} | {type:'pong'} */
const crypto = require('crypto');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_FRAME = 64 * 1024;

function frame(op, payload) {
  const b = Buffer.isBuffer(payload) ? payload : Buffer.from(payload);
  const n = b.length;
  const h = n < 126 ? Buffer.from([0x80 | op, n]) : n < 65536 ? Buffer.from([0x80 | op, 126, n >> 8, n & 255]) : (() => { const x = Buffer.alloc(10); x[0] = 0x80 | op; x[1] = 127; x.writeBigUInt64BE(BigInt(n), 2); return x; })();
  return Buffer.concat([h, b]);
}

class Client {
  constructor(sock) { this.sock = sock; this.buf = Buffer.alloc(0); this.authed = true; this.symbols = new Set(); this.alive = true; this.frag = null; }
  send(obj) { if (this.sock.destroyed || this.sock.writableLength > 1e6) return; try { this.sock.write(frame(1, JSON.stringify(obj))); } catch {} }
  close(code = 1000) { try { const b = Buffer.alloc(2); b.writeUInt16BE(code); this.sock.write(frame(8, b)); this.sock.end(); } catch {} }
}

/** attach(server, {getBroker()->broker|null}) */
function attach(server, { getBroker }) {
  const clients = new Set();
  const last = new Map();            // symbol -> last tick
  let stream = null, streamKey = '', status = 'idle', restartTimer = null;

  const wanted = () => { const s = new Set(); clients.forEach(c => c.symbols.forEach(x => s.add(x))); return [...s].sort(); };
  const broadcast = (type, obj, filter) => clients.forEach(c => { if (c.authed && (!filter || filter(c))) c.send({ type, ...obj }); });

  function restream() {
    clearTimeout(restartTimer);
    restartTimer = setTimeout(() => {
      const syms = wanted(), broker = getBroker();
      const key = syms.join(',') + '|' + (broker ? (broker.accountId || broker.label) : '');
      if (key === streamKey) return;
      if (stream) { stream.stop(); stream = null; }
      streamKey = key;
      if (!syms.length || !broker || !broker.streamPrices) { status = 'idle'; return; }
      stream = broker.streamPrices(syms, t => { last.set(t.symbol, t); broadcast('tick', t, c => c.symbols.has(t.symbol)); }, st => { status = st; broadcast('stream', { status: st }); });
    }, 150);
  }

  function handle(c, msg) {
    if (msg.op === 'ping') return c.send({ type: 'pong', t: Date.now() });
    if (msg.op === 'subscribe' || msg.op === 'unsubscribe') {
      const list = (Array.isArray(msg.symbols) ? msg.symbols : [msg.symbol]).map(s => String(s || '').toUpperCase().trim()).filter(s => /^[A-Z0-9_.]{2,20}$/.test(s));
      for (const s of list) { if (msg.op === 'subscribe') { if (c.symbols.size >= 30) { c.send({ type: 'error', message: 'Max 30 symbols per connection' }); break; } c.symbols.add(s); const t = last.get(s); if (t) c.send({ type: 'tick', ...t }); } else c.symbols.delete(s); }
      c.send({ type: 'subscribed', symbols: [...c.symbols] });
      if (!getBroker()) c.send({ type: 'error', message: 'No broker connected yet — ticks will start after you connect' });
      return restream();
    }
    c.send({ type: 'error', message: 'Unknown op' });
  }

  function onData(c, chunk) {
    c.buf = Buffer.concat([c.buf, chunk]);
    for (;;) {
      const b = c.buf; if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 15, masked = !!(b[1] & 0x80); let len = b[1] & 127, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > MAX_FRAME) return c.close(1009);
      if (!masked) return c.close(1002);
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4), data = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
      c.buf = b.subarray(off + 4 + len);
      if (op === 8) return c.close(1000);
      if (op === 9) { c.sock.write(frame(10, data)); continue; }
      if (op === 10) { c.alive = true; continue; }
      if (op === 0 || op === 1 || op === 2) {
        c.frag = op ? [data] : (c.frag ? (c.frag.push(data), c.frag) : null);
        if (!fin) continue;
        const txt = Buffer.concat(c.frag || []).toString('utf8'); c.frag = null;
        let m; try { m = JSON.parse(txt); } catch { c.send({ type: 'error', message: 'Invalid JSON' }); continue; }
        if (m && typeof m === 'object') handle(c, m);
      }
    }
  }

  server.on('upgrade', (req, sock) => {
    const url = new URL(req.url, 'http://x');
    if (url.pathname !== '/ws' || String(req.headers.upgrade).toLowerCase() !== 'websocket' || !req.headers['sec-websocket-key']) { sock.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); return sock.destroy(); }
    const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + GUID).digest('base64');
    sock.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);
    sock.setNoDelay(true);
    const c = new Client(sock); clients.add(c);
    sock.on('data', d => { try { onData(c, d); } catch { sock.destroy(); } });
    const drop = () => { if (clients.delete(c)) restream(); };
    sock.on('close', drop); sock.on('error', drop);
    c.send({ type: 'ready', stream: status });
  });

  const ping = setInterval(() => clients.forEach(c => { if (!c.alive) return c.sock.destroy(); c.alive = false; try { c.sock.write(frame(9, '')); } catch {} }), 25000); ping.unref();

  return {
    clients, last, restream,
    event: (kind, msg) => broadcast('event', { kind, msg, t: Date.now() }),
    status: () => ({ clients: clients.size, symbols: wanted(), stream: status }),
    close: () => { clearInterval(ping); clearTimeout(restartTimer); if (stream) stream.stop(); clients.forEach(c => c.sock.destroy()); },
  };
}
module.exports = { attach, frame };
