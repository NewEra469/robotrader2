const Strategy = require('./strategy');
const { round } = require('./util');

/**
 * The trading engine. Every few seconds it checks whether a new candle has CLOSED.
 * When one has, it evaluates the strategy on closed candles only and trades.
 *   Price × MA : BUY when a candle closes above the MA, SELL when it closes below
 *   MA cross   : fast MA crosses slow MA
 *   MACD       : MACD line crosses signal line
 * An opposite signal closes the bot's open trade and reverses.
 */
class Bot {
  constructor({ getBroker, store, now = () => Date.now(), tickMs = 5000, requireLiveConfirm = true }) {
    this.getBroker = getBroker; this.store = store; this.now = now; this.tickMs = tickMs; this.requireLiveConfirm = requireLiveConfirm;
    this.running = false; this.cfg = null; this.inst = null; this.lastClosedT = 0; this.lastBucketHandled = 0; this.nextCheck = 0;
    this.lastSignal = null; this.error = null; this.startedAt = null; this.pending = null;
    this.log = []; this.journal = []; this.dayStart = null; this.busy = false; this.timer = null; this._lastErr = '';
    const s = store?.loadState();
    if (s) { this.log = s.log || []; this.journal = s.journal || []; this.dayStart = s.dayStart || null; this.saved = s; }
  }

  addLog(k, m) {
    this.log.unshift({ t: this.now(), k, m }); if (this.log.length > 300) this.log.pop();
    if (k === 'trade' || k === 'risk') this.onChange?.();
    if (k !== 'info' || process.env.LOG_LEVEL === 'debug') console.log(`[${new Date(this.now()).toISOString()}] ${k.toUpperCase()} ${m}`);
    this.persist();
  }
  persist() {
    this.store?.saveState({ cfg: this.cfg, running: this.running, lastClosedT: this.lastClosedT, log: this.log.slice(0, 200), journal: this.journal.slice(0, 300), dayStart: this.dayStart });
  }
  get tfSec() { return this.cfg.tfMin * 60; }
  bucket() { return Math.floor(this.now() / 1000 / this.tfSec) * this.tfSec; }

  async start(cfg, { resume = false, confirmLive = false } = {}) {
    if (this.running) throw Object.assign(new Error('Bot is already running'), { status: 400 });
    const broker = this.getBroker(); if (!broker) throw Object.assign(new Error('Not connected to a broker'), { status: 400 });
    cfg = { ...cfg, symbol: String(cfg.symbol || '').trim() };
    const bad = Strategy.validate(cfg); if (bad) throw Object.assign(new Error(bad), { status: 400 });
    if (this.requireLiveConfirm && broker.isReal !== false && !confirmLive && !resume)
      throw Object.assign(new Error('This looks like a REAL-MONEY account. Confirm to start trading it.'), { status: 409, code: 'CONFIRM_LIVE' });
    const inst = await broker.getInstrument(cfg.symbol);
    if (cfg.lots < inst.minLot) throw Object.assign(new Error(`Minimum lot for ${cfg.symbol} is ${inst.minLot}`), { status: 400 });
    this.cfg = cfg; this.inst = inst;
    const { closed } = await this.fetchClosed();
    if (closed.length < 30) throw Object.assign(new Error(`Only ${closed.length} candles available for ${cfg.symbol} — not enough to calculate indicators`), { status: 400 });
    const last = closed[closed.length - 1];
    const sameMarket = this.saved && this.saved.cfg && this.saved.cfg.symbol === cfg.symbol && this.saved.cfg.tfMin === cfg.tfMin;
    this.lastClosedT = resume && sameMarket && this.saved.lastClosedT ? this.saved.lastClosedT : last.t;
    this.lastBucketHandled = 0; this.nextCheck = 0; this.pending = null; this.error = null; this.startedAt = this.now(); this.running = true;
    this.addLog('info', `Bot ${resume ? 'resumed' : 'started'} · ${cfg.symbol} ${tfName(cfg.tfMin)} · ${describe(cfg)} · ${cfg.lots} lots`);
    this.persist();
    if (!this.timer) { this.timer = setInterval(() => this.tick().catch(() => {}), this.tickMs); this.timer.unref?.(); }
    if (!resume && cfg.enterStart) { try { await this.evaluate(closed, { force: true }); } catch (e) { this.fail('Entry on start failed', e); } }
    if (this.lastClosedT < last.t) { try { await this.evaluate(closed, {}); this.lastClosedT = last.t; } catch (e) { this.fail('Catch-up evaluation failed', e); } }
    this.persist();
  }

  async stop({ closePositions = false, reason = 'Bot stopped' } = {}) {
    if (closePositions) await this.closeAll(reason).catch(e => this.fail('Close on stop failed', e));
    this.running = false; this.pending = null;
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    this.addLog('info', reason); this.persist(); this.store?.flush();
  }

  fail(prefix, e) { const m = `${prefix}: ${e.message}`; this.error = m; if (m !== this._lastErr) { this._lastErr = m; this.addLog('error', m); } }

  async tick() {
    if (!this.running || this.busy) return;
    this.busy = true;
    try {
      await this.checkRisk();
      if (this.running) await this.checkCandle();
      if (this.running && this.pending) await this.retryPending();
      if (this.running) { this.error = null; this._lastErr = ''; }
    } catch (e) { this.fail('Tick', e); }
    finally { this.busy = false; }
  }

  async fetchClosed() {
    const broker = this.getBroker();
    const candles = await broker.getCandles(this.cfg.symbol, this.cfg.tfMin, 500);
    const b = this.bucket();
    const closed = candles.filter(c => c.t < b && c.complete !== false).sort((x, y) => x.t - y.t);
    return { closed, bucket: b };
  }

  async checkCandle() {
    const nowMs = this.now(), b = this.bucket();
    if (b <= this.lastBucketHandled || nowMs < this.nextCheck) return;
    const { closed } = await this.fetchClosed();
    const last = closed[closed.length - 1];
    if (last && last.t > this.lastClosedT) {
      const t = last.t;
      try { await this.evaluate(closed, {}); } finally { this.lastClosedT = t; this.persist(); }
    }
    if (last && last.t >= b - this.tfSec) this.lastBucketHandled = b;               // caught up with the candle that just closed
    else this.nextCheck = nowMs + (nowMs / 1000 - b < 60 ? 4000 : 30000);          // broker not published yet, or market closed
  }

  /** Decide from closed candles. `force` = act on the current side even without a fresh cross. */
  async evaluate(closed, { force = false } = {}) {
    const closes = closed.map(c => c.c), { state } = Strategy.states(closes, this.cfg), n = state.length, cur = state[n - 1];
    const idx = closed.findIndex(c => c.t === this.lastClosedT);
    const prev = idx >= 0 && idx < n - 1 ? state[idx] : state[n - 2];
    if (cur === 0) return;
    if (!force && cur === prev) return;
    const type = cur > 0 ? 'BUY' : 'SELL', last = closed[n - 1];
    const why = this.cfg.strat === 'macd' ? 'MACD crossed ' + (cur > 0 ? 'above' : 'below') + ' signal' : this.cfg.strat === 'cross' ? 'fast MA crossed ' + (cur > 0 ? 'above' : 'below') + ' slow MA' : `candle closed ${cur > 0 ? 'above' : 'below'} ${this.cfg.maType}(${this.cfg.maPeriod})`;
    this.lastSignal = { type, t: this.now(), candleT: last.t, price: last.c, why };
    this.addLog('signal', `${type} — ${why} @ ${last.c}`);
    await this.act(type);
  }

  async act(type) {
    const broker = this.getBroker();
    const mine = (await broker.getPositions()).filter(p => p.mine && p.symbol.toUpperCase() === this.cfg.symbol.toUpperCase());
    for (const p of mine.filter(p => p.type !== type)) await this.closeOne(p, 'Reverse signal');
    if (mine.some(p => p.type === type)) { this.addLog('info', `Already ${type} on ${this.cfg.symbol} — nothing to do`); return; }
    try { await this.open(type, 'signal'); this.pending = null; }
    catch (e) { this.pending = { type, attempts: 1, notBefore: this.now() + 4000 }; this.fail(`Open ${type} failed (will retry)`, e); }
  }

  async retryPending() {
    const p = this.pending; if (!p || this.now() < p.notBefore) return;
    try { await this.open(p.type, 'retry'); this.pending = null; }
    catch (e) { p.attempts++; p.notBefore = this.now() + 4000; if (p.attempts > 3) { this.pending = null; this.addLog('error', `Giving up on ${p.type} after 3 attempts: ${e.message}`); } else this.fail(`Retry ${p.type} failed`, e); }
  }

  async open(type, reason) {
    const broker = this.getBroker(), c = this.cfg, { pip, digits } = this.inst;
    const px = await broker.getPrice(c.symbol);
    if (px.tradeable === false) throw new Error('Market is closed for ' + c.symbol);
    const ref = type === 'BUY' ? px.ask : px.bid, d = type === 'BUY' ? 1 : -1;
    const sl = c.sl > 0 ? round(ref - d * c.sl * pip, digits) : 0, tp = c.tp > 0 ? round(ref + d * c.tp * pip, digits) : 0;
    const r = await broker.openMarket({ symbol: c.symbol, type, lots: c.lots, sl, tp, comment: 'RT' });
    this.addLog('trade', `${type} ${c.lots} ${c.symbol} @ ~${ref}${sl ? ' SL ' + sl : ''}${tp ? ' TP ' + tp : ''} (${reason}) #${r.id}`);
    return r;
  }

  async closeOne(p, reason) {
    const r = await this.getBroker().closePosition(p.id, p);
    const pnl = r?.pnl ?? p.pnl ?? 0;
    this.journal.unshift({ id: p.id, symbol: p.symbol, type: p.type, lots: p.lots, entry: p.entry, exit: r?.price || p.current, pnl, openT: p.openTime, closeT: Math.floor(this.now() / 1000), reason, digits: this.inst?.digits });
    if (this.journal.length > 300) this.journal.pop();
    this.addLog('trade', `Closed ${p.type} ${p.symbol} #${p.id} · P&L ${pnl >= 0 ? '+' : ''}${(+pnl).toFixed(2)} (${reason})`);
    this.persist();
    return r;
  }

  async closeAll(reason = 'Close all', { onlyMine = false } = {}) {
    const ps = (await this.getBroker().getPositions()).filter(p => !onlyMine || p.mine);
    let failed = 0;
    for (const p of ps) { try { await this.closeOne(p, reason); } catch (e) { failed++; this.addLog('error', `Could not close #${p.id}: ${e.message}`); } }
    return { closed: ps.length - failed, failed };
  }

  async closeById(id) {
    const p = (await this.getBroker().getPositions()).find(x => String(x.id) === String(id));
    if (!p) throw Object.assign(new Error('Position not found (already closed?)'), { status: 404 });
    return this.closeOne(p, 'Manual');
  }

  async manualOrder({ symbol, type, lots, sl, tp }) {
    const broker = this.getBroker(); if (!broker) throw Object.assign(new Error('Not connected to a broker'), { status: 400 });
    if (!['BUY', 'SELL'].includes(type)) throw Object.assign(new Error('type must be BUY or SELL'), { status: 400 });
    if (!(lots >= 0.01 && lots <= 100)) throw Object.assign(new Error('Lot size must be 0.01–100'), { status: 400 });
    const inst = await broker.getInstrument(symbol), px = await broker.getPrice(symbol), ref = type === 'BUY' ? px.ask : px.bid, d = type === 'BUY' ? 1 : -1;
    const o = { symbol, type, lots, comment: 'RT', sl: sl > 0 ? round(ref - d * sl * inst.pip, inst.digits) : 0, tp: tp > 0 ? round(ref + d * tp * inst.pip, inst.digits) : 0 };
    const r = await broker.openMarket(o);
    this.addLog('trade', `Manual ${type} ${lots} ${symbol} @ ~${ref} #${r.id}`);
    return r;
  }

  /** Daily loss limit uses equity vs the first equity seen today (UTC). */
  async checkRisk() {
    const broker = this.getBroker(), a = await broker.getAccount();
    this.trackDay(a);
    const loss = this.dayStart.equity - a.equity;
    if (this.cfg.maxLoss > 0 && loss >= this.cfg.maxLoss && this.running) {
      this.addLog('risk', `Max daily loss reached (${loss.toFixed(2)} ≥ ${this.cfg.maxLoss}) — closing bot trades and stopping`);
      await this.closeAll('Max daily loss', { onlyMine: true }).catch(e => this.fail('Risk close failed', e));
      await this.stop({ reason: 'Bot stopped by daily-loss limit' });
    }
  }
  trackDay(a) {
    const day = new Date(this.now()).toISOString().slice(0, 10);
    if (!this.dayStart || this.dayStart.date !== day) { this.dayStart = { date: day, equity: a.equity, balance: a.balance }; this.persist(); }
    return this.dayStart;
  }

  status() {
    return { running: this.running, cfg: this.cfg, lastSignal: this.lastSignal, lastClosedT: this.lastClosedT, error: this.error, startedAt: this.startedAt, pip: this.inst?.pip, digits: this.inst?.digits };
  }
}

const tfName = m => (m < 60 ? 'M' + m : m < 1440 ? 'H' + m / 60 : 'D1');
const describe = c => (c.strat === 'pma' ? `Price × ${c.maType}(${c.maPeriod})` : c.strat === 'cross' ? `${c.fastType}(${c.fastPeriod}) × ${c.slowType}(${c.slowPeriod})` : `MACD(${c.macdFast},${c.macdSlow},${c.macdSignal})`);

module.exports = { Bot, tfName, describe };
