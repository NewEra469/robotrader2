const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/** Tiny JSON persistence. Saved broker credentials are encrypted with AES-256-GCM. The key comes from a random
 *  secret file that the server creates inside DATA_DIR on first start (see server.js), not from any dashboard key. */
class Store {
  constructor(dir, secret) {
    this.dir = dir; this.secret = secret; this.ok = false; this.timer = null; this.pending = null;
    try { fs.mkdirSync(dir, { recursive: true }); fs.accessSync(dir, fs.constants.W_OK); this.ok = true; } catch { this.ok = false; }
  }
  _file(n) { return path.join(this.dir, n); }
  _write(n, text) { if (!this.ok) return; try { const f = this._file(n), tmp = f + '.tmp'; fs.writeFileSync(tmp, text, { mode: 0o600 }); fs.renameSync(tmp, f); } catch { /* ignore */ } }
  _read(n) { try { return fs.readFileSync(this._file(n), 'utf8'); } catch { return null; } }

  loadState() { try { return JSON.parse(this._read('state.json') || 'null'); } catch { return null; } }
  saveState(obj) { // debounced
    this.pending = obj; if (this.timer) return;
    this.timer = setTimeout(() => { this.timer = null; this._write('state.json', JSON.stringify(this.pending)); }, 1000);
    this.timer.unref?.();
  }
  flush() { if (this.timer) { clearTimeout(this.timer); this.timer = null; this._write('state.json', JSON.stringify(this.pending)); } }

  _key() { return crypto.scryptSync(this.secret, 'robotrader-creds-v1', 32); }
  saveCreds(obj) {
    if (!this.ok) return false;
    const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', this._key(), iv);
    const data = Buffer.concat([c.update(JSON.stringify(obj), 'utf8'), c.final()]);
    this._write('creds.enc', JSON.stringify({ iv: iv.toString('base64'), tag: c.getAuthTag().toString('base64'), data: data.toString('base64') }));
    return true;
  }
  loadCreds() {
    try {
      const j = JSON.parse(this._read('creds.enc') || 'null'); if (!j) return null;
      const d = crypto.createDecipheriv('aes-256-gcm', this._key(), Buffer.from(j.iv, 'base64')); d.setAuthTag(Buffer.from(j.tag, 'base64'));
      return JSON.parse(Buffer.concat([d.update(Buffer.from(j.data, 'base64')), d.final()]).toString('utf8'));
    } catch { return null; }
  }
  clearCreds() { try { fs.unlinkSync(this._file('creds.enc')); } catch { /* none */ } }
}
module.exports = { Store };
