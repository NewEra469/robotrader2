/* MetaTrader 5 adapter. Talks to the local mt5_bridge.py (MT5 terminal + Python running under Wine in the same container).
   No API token: you log in with your MT5 account number, password and broker server. */
const { http, ApiError, sleep } = require('../util');

const TAG_MAGIC = 7777;
class Mt5Broker {
  constructor() { this.name = 'mt5'; this.insts = new Map(); }
  get base() { return process.env.MT5_BRIDGE_URL || 'http://127.0.0.1:8765'; }
  async _call(method, path, body, timeout = 30000) { return (await http(method, this.base + path, { body, timeout })).data; }

  async connect({ login, password, server } = {}) {
    if (!login || !password || !server) throw new ApiError('MT5 login, password and broker server are required', 400);
    // the bridge may still be starting right after a container restart
    let h, t0 = Date.now();
    for (;;) {
      try { h = await this._call('GET', '/health', undefined, 4000); break; }
      catch (e) { if (Date.now() - t0 > 90000) throw new ApiError('The MT5 bridge is not running in this container (check that start.sh started the bridge).' + e.message, 503); await sleep(2000); }
    }
    if (!h.terminalInstalled) throw new ApiError('The MT5 terminal is still installing in the container — wait a few minutes and try again', 503);
    const a = await this._call('POST', '/login', { login: String(login), password, server }, 150000);
    this.isReal = !!a.isReal;
    this.label = `MT5 ${a.login} @ ${a.server}`;
    return a;
  }

  async getAccount() { return this._call('GET', '/account'); }
  async getInstrument(symbol) {
    const k = String(symbol).toUpperCase();
    if (!this.insts.has(k)) this.insts.set(k, await this._call('GET', '/instrument?symbol=' + encodeURIComponent(symbol)));
    return this.insts.get(k);
  }
  getPrice(symbol) { return this._call('GET', '/tick?symbol=' + encodeURIComponent(symbol)); }
  getCandles(symbol, tfMin, count = 300) { return this._call('GET', `/candles?symbol=${encodeURIComponent(symbol)}&tf=${tfMin}&count=${Math.min(count, 5000)}`, undefined, 60000); }
  getPositions() { return this._call('GET', '/positions'); }
  openMarket({ symbol, type, lots, sl, tp, comment = 'RT' }) { return this._call('POST', '/order', { symbol, type, lots, sl, tp, comment }, 60000); }
  closePosition(id) { return this._call('POST', '/close', { id }, 60000); }
  searchSymbols(q) { return this._call('GET', '/symbols?q=' + encodeURIComponent(q || '')); }

  /** Live ticks: polls the terminal's own quote feed ~4×/s and emits every change. */
  streamPrices(symbols, onTick, onStatus = () => {}) {
    let stopped = false; const seen = {};
    (async () => {
      let ok = false;
      while (!stopped) {
        try {
          const r = await this._call('GET', '/ticks?symbols=' + symbols.map(encodeURIComponent).join(','), undefined, 8000);
          if (!ok) { ok = true; onStatus('connected'); }
          for (const [s, t] of Object.entries(r)) { const key = t.bid + '/' + t.ask + '/' + t.time; if (seen[s] !== key) { seen[s] = key; onTick({ symbol: s, ...t }); } }
          await sleep(250);
        } catch (e) { if (stopped) return; ok = false; onStatus('reconnecting: ' + e.message); await sleep(3000); }
      }
    })();
    return { stop() { stopped = true; } };
  }
}
module.exports = { Mt5Broker, TAG_MAGIC };
