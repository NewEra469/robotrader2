const { OandaBroker } = require('./oanda');
const { Mt5Broker } = require('./mt5');
const REGISTRY = { mt5: () => new Mt5Broker(), oanda: () => new OandaBroker() };
function create(name) { const f = REGISTRY[String(name).toLowerCase()]; if (!f) throw Object.assign(new Error('Unknown broker: ' + name + ' (supported: mt5, oanda)'), { status: 400 }); return f(); }
module.exports = { create, REGISTRY };
