/* OANDA v20 REST adapter (free practice account, real prices, real order execution). */
const { http, ApiError, num, round } = require('../util');

const STREAM_HOSTS = { practice: 'https://stream-fxpractice.oanda.com', live: 'https://stream-fxtrade.oanda.com' };
const HOSTS = { practice: 'https://api-fxpractice.oanda.com', live: 'https://api-fxtrade.oanda.com' };
const GRAN = { 1: 'M1', 5: 'M5', 15: 'M15', 30: 'M30', 60: 'H1', 240: 'H4', 1440: 'D' };
const SPECIAL = { XAUUSD: 'XAU_USD', XAGUSD: 'XAG_USD', US30: 'US30_USD', NAS100: 'NAS100_USD', US500: 'SPX500_USD', GER40: 'DE30_EUR', UK100: 'UK100_GBP', JP225: 'JP225_USD', USOIL: 'WTICO_USD' };
const UNITS_PER_LOT = { XAU_USD: 100, XAG_USD: 5000, WTICO_USD: 1000 };
const PIP_OVERRIDE = { XAU_USD: 0.1, XAG_USD: 0.01 };   // match the MT5 convention shown in the dashboard
const FIAT = new Set(['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'NZD', 'CAD', 'CHF', 'SGD', 'HKD', 'SEK', 'NOK', 'DKK', 'PLN', 'ZAR', 'MXN', 'TRY', 'CNH', 'CZK', 'HUF', 'THB']);
const TAG = 'robotrader';

function toOanda(sym) {
  const s = String(sym).toUpperCase();
  if (SPECIAL[s]) return SPECIAL[s];
  if (/^[A-Z0-9]{2,10}_[A-Z]{3}$/.test(s)) return s;
  if (/^[A-Z]{6}$/.test(s)) return s.slice(0, 3) + '_' + s.slice(3);
  return s;
}
function fromOanda(name) {
  for (const [k, v] of Object.entries(SPECIAL)) if (v === name) return k;
  return name.replace('_', '');
}
function unitsPerLot(name) {
  if (UNITS_PER_LOT[name]) return UNITS_PER_LOT[name];
  const [a, b] = name.split('_');
  return FIAT.has(a) && FIAT.has(b) ? 100000 : 1;
}
function parseTime(s) { return Math.floor(Date.parse(String(s).replace(/(\.\d{3})\d+Z$/, '$1Z')) / 1000); }

class OandaBroker {
  constructor() { this.name = 'oanda'; this.insts = new Map(); }

  async connect({ token, accountId, env = 'practice' } = {}) {
    if (!token) throw new ApiError('OANDA API token is required', 400);
    if (!['practice', 'live'].includes(env)) throw new ApiError('env must be practice or live', 400);
    this.base = process.env.OANDA_BASE_URL || HOSTS[env];
    this.env = env; this.isReal = env === 'live';
    this.auth = { authorization: 'Bearer ' + token };
    if (!accountId) {
      const r = await this._get('/v3/accounts');
      const list = r.accounts || [];
      if (!list.length) throw new ApiError('This OANDA token has no accounts', 400);
      accountId = list[0].id;
    }
    this.accountId = accountId;
    const acc = await this.getAccount();
    this.label = `OANDA ${env} · ${accountId}`;
    return acc;
  }
  async _get(path) { return (await http('GET', this.base + path, { headers: this.auth })).data; }

  async getAccount() {
    const a = (await this._get(`/v3/accounts/${this.accountId}/summary`)).account;
    return { balance: num(a.balance), equity: num(a.NAV), margin: num(a.marginUsed), freeMargin: num(a.marginAvailable), currency: a.currency, login: a.id, name: a.alias || a.id, server: 'OANDA ' + this.env };
  }

  async getInstrument(symbol) {
    const name = toOanda(symbol);
    if (this.insts.has(name)) return this.insts.get(name);
    const r = await this._get(`/v3/accounts/${this.accountId}/instruments?instruments=${encodeURIComponent(name)}`);
    const i = (r.instruments || [])[0];
    if (!i) throw new ApiError(`Instrument ${name} is not available on this OANDA account`, 404);
    const digits = i.displayPrecision;
    const pip = PIP_OVERRIDE[name] || +Math.pow(10, i.pipLocation).toFixed(Math.max(0, -i.pipLocation));
    const info = { symbol: fromOanda(name), brokerSymbol: name, digits, pip, minLot: Math.max(0.01, (+i.minimumTradeSize || 1) / unitsPerLot(name)), lotStep: 0.01, unitsPerLot: unitsPerLot(name), unitsPrecision: i.tradeUnitsPrecision || 0 };
    this.insts.set(name, info);
    return info;
  }

  async getPrice(symbol) {
    const name = toOanda(symbol);
    const r = await this._get(`/v3/accounts/${this.accountId}/pricing?instruments=${encodeURIComponent(name)}`);
    const p = (r.prices || [])[0];
    if (!p || !p.bids?.length || !p.asks?.length) throw new ApiError(`No price for ${name}`, 404);
    return { bid: num(p.bids[0].price), ask: num(p.asks[0].price), time: parseTime(p.time), tradeable: p.tradeable !== false };
  }

  /** Bid candles, oldest → newest, like an MT5 chart. */
  async getCandles(symbol, tfMin, count = 300) {
    const g = GRAN[tfMin]; if (!g) throw new ApiError('Unsupported timeframe', 400);
    const name = toOanda(symbol);
    const r = await this._get(`/v3/instruments/${encodeURIComponent(name)}/candles?price=B&granularity=${g}&count=${Math.min(count, 5000)}`);
    return (r.candles || []).filter(c => c.bid).map(c => ({ t: parseTime(c.time), o: num(c.bid.o), h: num(c.bid.h), l: num(c.bid.l), c: num(c.bid.c), v: c.volume, complete: !!c.complete }));
  }

  async getPositions() {
    const r = await this._get(`/v3/accounts/${this.accountId}/openTrades`);
    const trades = r.trades || [];
    const names = [...new Set(trades.map(t => t.instrument))];
    const px = {};
    if (names.length) {
      const pr = await this._get(`/v3/accounts/${this.accountId}/pricing?instruments=${names.map(encodeURIComponent).join(',')}`);
      (pr.prices || []).forEach(p => { px[p.instrument] = { bid: num(p.bids?.[0]?.price), ask: num(p.asks?.[0]?.price) }; });
    }
    return trades.map(t => {
      const units = num(t.currentUnits), buy = units > 0, q = px[t.instrument] || {};
      return {
        id: String(t.id), symbol: fromOanda(t.instrument), type: buy ? 'BUY' : 'SELL', lots: round(Math.abs(units) / unitsPerLot(t.instrument), 4),
        entry: num(t.price), current: buy ? q.bid : q.ask, pnl: num(t.unrealizedPL) || 0,
        sl: num(t.stopLossOrder?.price) || 0, tp: num(t.takeProfitOrder?.price) || 0,
        openTime: parseTime(t.openTime), mine: t.clientExtensions?.tag === TAG,
      };
    });
  }

  async openMarket({ symbol, type, lots, sl, tp, comment = 'RT' }) {
    const inst = await this.getInstrument(symbol);
    const units = Math.round(lots * inst.unitsPerLot * Math.pow(10, inst.unitsPrecision)) / Math.pow(10, inst.unitsPrecision);
    if (!(units >= 1) && inst.unitsPrecision === 0) throw new ApiError(`Lot size ${lots} is below the minimum for ${inst.brokerSymbol}`, 400);
    const order = {
      type: 'MARKET', instrument: inst.brokerSymbol, units: String(type === 'BUY' ? units : -units), timeInForce: 'FOK', positionFill: 'DEFAULT',
      clientExtensions: { tag: TAG, comment }, tradeClientExtensions: { tag: TAG, comment },
    };
    if (sl) order.stopLossOnFill = { price: (+sl).toFixed(inst.digits), timeInForce: 'GTC' };
    if (tp) order.takeProfitOnFill = { price: (+tp).toFixed(inst.digits), timeInForce: 'GTC' };
    const r = (await http('POST', `${this.base}/v3/accounts/${this.accountId}/orders`, { headers: this.auth, body: { order } })).data;
    if (r.orderFillTransaction?.tradeOpened) return { id: String(r.orderFillTransaction.tradeOpened.tradeID), price: num(r.orderFillTransaction.price) };
    const why = r.orderCancelTransaction?.reason || r.orderRejectTransaction?.rejectReason || 'order not filled';
    throw new ApiError(`OANDA rejected the order: ${why}`, 400, r);
  }

  async closePosition(id) {
    const r = (await http('PUT', `${this.base}/v3/accounts/${this.accountId}/trades/${encodeURIComponent(id)}/close`, { headers: this.auth, body: { units: 'ALL' } })).data;
    const f = r.orderFillTransaction;
    if (!f) throw new ApiError('OANDA did not confirm the close', 502, r);
    return { pnl: num(f.pl), price: num(f.price) };
  }

  /** Live price stream (OANDA pricing/stream, newline-delimited JSON). Reconnects by itself.
      onTick({symbol,bid,ask,time,tradeable}); returns {stop()}. */
  streamPrices(symbols, onTick, onStatus = () => {}) {
    const names = symbols.map(toOanda), base = process.env.OANDA_STREAM_URL || STREAM_HOSTS[this.env];
    let stopped = false, ctl = null, fails = 0;
    const run = async () => {
      while (!stopped) {
        ctl = new AbortController();
        let watchdog = setTimeout(() => ctl.abort(), 20000);   // OANDA sends a heartbeat every 5s
        try {
          const res = await fetch(`${base}/v3/accounts/${this.accountId}/pricing/stream?instruments=${names.map(encodeURIComponent).join(',')}`, { headers: this.auth, signal: ctl.signal });
          if (!res.ok) throw new ApiError(`pricing stream → HTTP ${res.status}`, res.status);
          onStatus('connected'); fails = 0;
          const dec = new TextDecoder(); let buf = '';
          for await (const chunk of res.body) {
            clearTimeout(watchdog); watchdog = setTimeout(() => ctl.abort(), 20000);
            buf += dec.decode(chunk, { stream: true });
            let i;
            while ((i = buf.indexOf('\n')) >= 0) {
              const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
              if (!line) continue;
              let m; try { m = JSON.parse(line); } catch { continue; }
              if (m.type === 'PRICE' && m.bids?.length && m.asks?.length)
                onTick({ symbol: fromOanda(m.instrument), bid: num(m.bids[0].price), ask: num(m.asks[0].price), time: parseTime(m.time), tradeable: m.tradeable !== false });
            }
          }
          throw new Error('stream closed');
        } catch (e) {
          if (stopped) return;
          fails++; onStatus('reconnecting: ' + e.message);
          if (e.status === 401 || e.status === 403) { onStatus('stopped: ' + e.message); return; }
        } finally { clearTimeout(watchdog); }
        await new Promise(r => setTimeout(r, Math.min(30000, 1000 * 2 ** Math.min(fails, 5))));
      }
    };
    run();
    return { stop() { stopped = true; try { ctl && ctl.abort(); } catch {} } };
  }

  async searchSymbols(q) {
    const r = await this._get(`/v3/accounts/${this.accountId}/instruments`);
    const s = String(q || '').toUpperCase().replace('_', '');
    return (r.instruments || []).map(i => fromOanda(i.name)).filter(n => !s || n.includes(s)).slice(0, 40);
  }
}

module.exports = { OandaBroker, toOanda, fromOanda, unitsPerLot, parseTime };
